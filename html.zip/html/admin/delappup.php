<?php

	include ("library/checklogin.php");
    $operator = $_SESSION['operator_user'];
	
	include_once('library/config_read.php');
	
	$id=$_GET['id'];
	
	//�������ݿ�
    $conn= @mysql_connect('127.0.0.1','root','123456');
    mysql_select_db('radius',$conn);
    mysql_query('set character set  utf8');
    mysql_query('set names  utf8');
	
	$sql0="delete from appup where id=$id";
		$re0=mysql_query($sql0);
		
		header("Location:app_up.php");
	?>
