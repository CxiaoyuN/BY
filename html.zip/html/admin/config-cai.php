
                                <ul id="subnav">

					<li><a href="info.php">公告</a></li>
					<li><a href="tz.php">服务器信息</a></li>
					<li><a class="media" href="http://oepme7clh.bkt.clouddn.com/chu.pdf" target="blank">出卡简明</a></li>
					<li><a href="http://oepme7clh.bkt.clouddn.com/studayapp" target="blank">app制作视频</a></li> 
                                </ul>

                </div>
	
