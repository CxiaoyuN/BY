<?php
require_once('../html/admin/library/config_read.php');
require '../html/admin/library/opendb.php';
//检查用户
function check_username_pwd($username, $pwd){
   global $dbSocket;
   global $configValues;
    $query_sql = "SELECT * FROM ".$configValues['CONFIG_DB_TBL_RADCHECK']." WHERE username = '$username'";
    $re = $dbSocket->query($query_sql);
    if($row = $re->fetchRow()){
          $db_username = $row[1];
          $db_attribute = $row[2];
          $db_op = $row[3];
          $db_value = $row[4];
          if ($username == $db_username){
              if ($db_attribute == 'Cleartext-Password' || $db_attribute == 'User-Password'){
                  if ($db_value == $pwd)
                      return true;
              }

          }

        }else{
        return false;
    }

}
//获取流量
function get_user_used_traffic($username){
   global $dbSocket;
   global $configValues;
    $query_sql = "SELECT SUM(acctinputoctets + acctoutputoctets) FROM ".$configValues['CONFIG_DB_TBL_RADACCT']." WHERE username = '$username';";
    $re = $dbSocket->query($query_sql);
    if($row = $re->fetchRow()){
        if ($row[0] <> ''){
                return $row[0];
        }else{
                return 0;
        }
    }else{
        return false;
    }
}
//
function get_user_used_days($username){
   global $dbSocket;
   global $configValues;
    $query_sql = "SELECT IF(COUNT(radacctid>=1),(UNIX_TIMESTAMP() - IFNULL(UNIX_TIMESTAMP(AcctStartTime),0)),0) DIV 86400 FROM ".$configValues['CONFIG_DB_TBL_RADACCT']." WHERE username = '$username' AND AcctSessionTime >= 1 ORDER BY AcctStartTime LIMIT 1";
    $re = $dbSocket->query($query_sql);
    if($row = $re->fetchRow()){
        return $row[0];
    }else{
        return false;
    }

}
//
function get_user_total_traffic($username){
   global $dbSocket;
   global $configValues;
    $max_global_traffic = 0;
    $max_active_days = 0;
    $query_sql = "SELECT groupname FROM ".$configValues['CONFIG_DB_TBL_RADUSERGROUP']." WHERE username = '$username'";
    $re = $dbSocket->query($query_sql);
    if($row = $re->fetchRow()){
        $groupname = $row[0];
          $query_sql1 = "SELECT * FROM ".$configValues['CONFIG_DB_TBL_RADGROUPCHECK']." WHERE groupname = '$groupname'";
          $re1=$dbSocket->query($query_sql1);
          while($row1=$re1->fetchRow()){
              if ("Max-Global-Traffic" == $row1[2]){
                  $max_global_traffic = $row1[4];
              }elseif("Max-Active-Days" == $row1[2]){
                  $max_active_days = $row1[4];
              }
          }

    }
    $max=array();
    $max[0]=$max_global_traffic;
    $max[1]=$max_active_days;
    return $max;

}
//主程序
    $username = $_GET['username'];
    $pwd = $_GET['password'];
    $data=array();
    if(empty($username) or empty($pwd ) ){
        $data['error']=true;
        $data['code']=404;
        $data['message']= urlencode('用户或密码不存在');
        echo urldecode(json_encode($data));
        exit;
    }
    else {
        if (check_username_pwd($username,$pwd)){
                //分配数据
                $cur_traffic = get_user_used_traffic($username);
                $data['globalTrafficCount'] = $cur_traffic;
                //echo $cur_traffic;exit;
                $umax = get_user_total_traffic($username);
                $max_global_traffic=$umax[0];
                $max_active_days=$umax[1];
                //echo $max_global_traffic.$max_active_days;exit;
                $data['maxGlobalTraffic'] = ($max_global_traffic)*1024*1024;
                $data['maxActiveDays'] =$max_active_days;
                //echo $max_active_days;exit;
                $data['activeDaysCount'] =get_user_used_days($username);
                echo urldecode(json_encode($data));
        }
        else {
                $data['error']=true;
                $data['code']=404;
                $data['message']= urlencode('用户不存在');
                echo urldecode(json_encode($data));
        }
        }
?>
