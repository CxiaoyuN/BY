<?php
require_once('../html/admin/library/config_read.php');
require '../html/admin/library/opendb.php';
//检测更新
if(isset($_GET['name'])){
	$n=$_GET['name'];	
}else{
	echo '输入错误';exit;
}

$v=$_GET['version'];
$data=array();

//查看文件
	$sql1="select * from info where type=1 and sort=1 limit 1";
	$re = $dbSocket->query($sql1);
	$row1 = $re->fetchRow();
	$data['notice']=urlencode($row1[3]);
	//$data['notice']='qw';
	
	//$sql2="select * from appup where appname='$n' and apphao>'$v' order by apphao desc limit 1";
$sql="select * from appup where status=1 and apphao>'$v' order by apphao desc limit 1";
//$sqlw1="select * from appup";
$re = $dbSocket->query($sql);
$row2 = $re->fetchRow();
	//print_r($row2);exit;
	if($row2){
		//有新本
		$data['newVersion']=true;
		//echo $row2['appname'];exit;
		$data['name']=$row2['appname'];
		//$data['name']='jiji';
		$data['version']=$row2['apphao'];
		//$data['version']='iioo';
		$data['introd']=$row2['appinfo'];
		//$data['introd']='uuiui';
		$filesize=filesize('../html/admin/upfile/'.$row2['appfile']);
		//echo $filesize;exit;
		$data['size']=$filesize;
		$data['url']='http://121.18.238.5:8080/admin/upfile/'.$row2['appfile'];
		//$data['url']='11';
		$data['error']=false;
		$data['message']='';
		$data['code']=0;
	}else{
		
		$data['newVersion']=false;
		//echo $row2['appname'];exit;
		$data['name']='';
		//$data['name']='jiji';
		$data['version']='';
		//$data['version']='iioo';
		$data['introd']='';
		//$data['introd']='uuiui';
		//echo $filesize;exit;
		$data['size']=0;
		$data['url']='';
		$data['error']=true;
		$data['code']=0;
		//$data['url']='11';
		//$data['message']='';
	}
	//公告
	
//数据
/* 
$data['newVersion']=true;
$data['name']=true;
$data['version']=true;
$data['introd']=true;
$data['size']=true;
$data['url']=true;
$data['error']=true;
$data['message']=true;
 */
//
echo urldecode(json_encode($data));
?>
